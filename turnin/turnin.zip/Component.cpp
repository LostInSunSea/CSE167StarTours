#include "Component.h"



Component::Component()
{
}


Component::~Component()
{
}

void Component::draw(glm::mat4 trans, GLint shader)
{
}

void Component::update(glm::mat4 trans)
{
}
